# FULK Android

Native Android layer for FULK: Usage Access, Digital Boundary, Focus alarm, Api Bahtera streak reminders, and an animated Qur'anic-value campaign.

## Permissions
- Usage Access: required for real app usage statistics.
- Accessibility: explicitly enabled by the user for Digital Boundary overlay.
- Notifications: Android 13+ permission required for reminders.
- Exact alarm: optional/special access on Android 12+; FULK falls back to an inexact alarm when exact access is unavailable.

## Research boundary
The app does not claim that al-fulk literally means epistemic resilience or an app. The product is an implementation built after reconstructing the verse's structure and dialoguing it with situated epistemic agency.
